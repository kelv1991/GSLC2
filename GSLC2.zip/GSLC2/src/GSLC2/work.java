package GSLC2;

interface work{
	void working(String name);
}
