package GSLC2;

interface financial {
	void viewfinancial(int finance);
}
